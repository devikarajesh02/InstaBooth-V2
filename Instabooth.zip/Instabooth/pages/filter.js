console.log("Filter page loaded");

// Elements

const thumbnails =
    document.querySelectorAll(
        ".thumbnail"
    );

const thumbImages = [
    document.getElementById("thumb1"),
    document.getElementById("thumb2"),
    document.getElementById("thumb3")
];

const previewImage =
    document.getElementById(
        "previewImage"
    );

const filterButtonsContainer =
    document.getElementById(
        "filterButtons"
    );

const nextBtn =
    document.getElementById(
        "chooseThemeBtn"
    );

// Available filters.
// Add a new one here and a button appears automatically —
// no HTML changes needed.
const FILTERS = [
    { label: "Original", value: "none" },
    { label: "B&W",      value: "grayscale(100%)" },
    { label: "Noir",     value: "grayscale(100%) contrast(140%) brightness(95%)" },
    { label: "Sepia",    value: "sepia(80%) saturate(120%)" },
    { label: "Vintage",  value: "sepia(35%) contrast(90%) brightness(105%) saturate(85%)" },
    { label: "Warm",     value: "sepia(30%) saturate(140%) hue-rotate(-10deg) brightness(105%) contrast(105%)" },
    { label: "Cool",     value: "sepia(20%) hue-rotate(180deg) saturate(140%) brightness(105%) contrast(105%)" },
    { label: "Bright",   value: "brightness(130%)" },
    { label: "Vivid",    value: "saturate(160%) contrast(112%) brightness(105%)" }
];

// Photos

const photos =
    JSON.parse(
        sessionStorage.getItem(
            "photos"
        )
    ) || [];

console.log(
    "Photos:",
    photos
);

// Load thumbnails

photos.forEach((photo, index) => {

    if (photo && thumbImages[index]) {

        thumbImages[index].src = photo;

    }

});

// Current selected photo

let currentPhoto = 0;

// Filters for each photo

const photoFilters = [

    "none",

    "none",

    "none"

];

// Build the filter buttons from FILTERS

FILTERS.forEach(filterDef => {

    const button =
        document.createElement("button");

    button.className = "filter-btn";
    button.textContent = filterDef.label;
    button.dataset.filter = filterDef.value;

    button.addEventListener(
        "click",
        () => applyFilter(filterDef.value)
    );

    filterButtonsContainer.appendChild(button);

});

const filterButtons =
    filterButtonsContainer.querySelectorAll(
        ".filter-btn"
    );

// Apply a filter to the currently selected photo
// (updates the big preview AND that photo's thumbnail,
// so filters can be compared across photos at a glance).

function applyFilter(filterValue){

    photoFilters[currentPhoto] =
        filterValue;

    previewImage.style.filter =
        filterValue;

    const thumbImg =
        thumbImages[currentPhoto];

    if (thumbImg) {

        thumbImg.style.filter =
            filterValue;

    }

    updateActiveFilterButton();

}

// Highlight whichever filter button matches the
// current photo's applied filter.

function updateActiveFilterButton(){

    const activeValue =
        photoFilters[currentPhoto];

    filterButtons.forEach(button => {

        button.classList.toggle(
            "active",
            button.dataset.filter === activeValue
        );

    });

}

// Show selected photo

function showPhoto(index){

    currentPhoto =
        index;

    previewImage.src =
        photos[index];

    previewImage.style.filter =
        photoFilters[index];

    thumbnails.forEach(
        thumb => {

            thumb.classList.remove(
                "active"
            );

        }
    );

    thumbnails[index]
        .classList.add(
            "active"
        );

    updateActiveFilterButton();

}

// Load first photo

if(
    photos.length > 0 &&
    previewImage
){

    showPhoto(0);

}

// Thumbnail click

thumbnails.forEach(
    thumb => {

        thumb.addEventListener(
            "click",
            () => {

                const index =
                    Number(
                        thumb.dataset.index
                    );

                showPhoto(
                    index
                );

            }
        );

    }
);

// Continue

nextBtn?.addEventListener(
    "click",
    () => {

        sessionStorage.setItem(
            "photoFilters",
            JSON.stringify(
                photoFilters
            )
        );

        window.location.href =
            "editor.html";

    }
);