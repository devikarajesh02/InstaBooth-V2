console.log("About page loaded");

const sections = document.querySelectorAll(".reveal-section");
const navTabs = document.querySelectorAll(".nav-tab");

const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
).matches;

// ====================
// Fade-in reveal on scroll
// ====================

if (prefersReducedMotion) {
    sections.forEach(section => section.classList.add("is-visible"));
} else {
    const revealObserver = new IntersectionObserver(
        (entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("is-visible");
                    observer.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.15 }
    );

    sections.forEach(section => revealObserver.observe(section));
}

// ====================
// Scrollspy — highlight the nav tab matching
// whichever section is in view
// ====================

const spyObserver = new IntersectionObserver(
    (entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;

            const id = entry.target.id;
            navTabs.forEach(tab => {
                tab.classList.toggle("active", tab.dataset.target === id);
            });
        });
    },
    { threshold: 0, rootMargin: "-35% 0px -55% 0px" }
);

sections.forEach(section => spyObserver.observe(section));

// ====================
// Click a nav tab to jump to that section
// ====================

navTabs.forEach(tab => {
    tab.addEventListener("click", () => {
        const target = document.getElementById(tab.dataset.target);
        if (!target) return;

        target.scrollIntoView({
            behavior: prefersReducedMotion ? "auto" : "smooth",
            block: "start"
        });
    });
});